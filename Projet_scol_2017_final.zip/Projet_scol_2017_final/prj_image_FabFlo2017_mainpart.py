import pygame
from prj_image_FabFlo2017_def_fonctions import *
pygame.init
fen = pygame.display.set_mode((980,650))
# partie où je fais apparaître mes icônes.
surf_img = ouvrir_fichier_img_pygame0()
if surf_img != None :
        l0 = surf_img.get_width()
        h0 = surf_img.get_height()
pos = pygame.Rect ((10,20),(l0,h0))
fen.blit(surf_img,pos)
surf_img0 = ouvrir_fichier_img_pygame1()
if surf_img0 != None :
        l1 = surf_img0.get_width()
        h1 = surf_img0.get_height()
pos0 = pygame.Rect ((140,20),(l1,h1))
fen.blit(surf_img0,pos0)
surf_img_exit = ouvrir_fichier_img_pygame_exit()
if surf_img0 != None :
        l_exit = surf_img0.get_width()
        h_exit = surf_img0.get_height()
pos_exit = pygame.Rect ((310,20),(l_exit,h_exit))
fen.blit(surf_img_exit,pos_exit)
pygame.display.update()
pygame.font.init()
done = False
while done == False :
	# On va faire apparaître un peu de texte.
	myfont = pygame.font.SysFont("Arial", 15)
	label = myfont.render("Cliquez sur l'icône correspondante à l'action voulue.", 1, (255,0,0))
	fen.blit(label,(10,90))
	pygame.display.update()
	# On va récupérer le moment où l'utilisateur va cliquer sur l'une des deux icônes
	# et renvoyer les informations relatives à l'icône cliquée.
	ok = 1
	while ok :
		e = pygame.event.get()
		for a in e :
			if a.type == pygame.MOUSEBUTTONUP :
				x,y = pygame.mouse.get_pos()
				rect_noir = pygame.image.load('eff_text.ppm')
				fen.blit(rect_noir,(10,90))
				pygame.display.update()
				if 10<=x<=130 and 20<=y<=80 :
					label = myfont.render("***** inverser les couleurs de l'image. *****",1,(255,255,0))
					rep = "inv"
					ok = 0
				elif 140<=x<=300 and 20<=y<=80 :
					label = myfont.render("***** rendre monochrome l'image. *****",1,(0,255,255))
					rep = "mon"
					ok = 0
	fen.blit(label,(10,90))
	pygame.display.update()
	# Partie principale où je rencontre le problème d'affichage
	l,h,surf_img1,l_rvb_img1= lecture_fichier_image()
	
	if len(l_rvb_img1) :
		pos1 = pygame.Rect((10,120),(l,h))
		fen.blit(surf_img1,pos1)
		pygame.display.update()
		pygame.time.wait(3000)
		if rep == "inv" :
			l_rvb_img2 = inverse_couleurs(l_rvb_img1)
		if rep == "mon" :
			x1,y1 = 10,120
			x2,y2 = 10+l,120+h
			l_rvb_img2 = niv_gris_zone (l_rvb_img1,l,h)
		surf_img2 = liste_vers_surface(l,h,l_rvb_img2)
		pos2 = pygame.Rect((l+20,120),(l,h))
		fen.blit(surf_img2,pos2)
		pygame.display.update()
		#petite sauvegarde possible sous les formats BMP,TGA,PNG,JPEG,PPM
		re = input ("Voulez vous sauvegarder ? ('o' ou 'n')")
		if re == 'o' :
			name = input("Veuillez donner le nom du nouveau fichier (.ppm ou .jpg) : ")
			if rep == 'inv' :
				pygame.image.save(surf_img2,name)
			if rep == 'mon' :
				pygame.image.save(surf_img2,name)
		pygame.time.wait(3000)
	rect_noir = pygame.image.load('eff_text.ppm')
	fen.blit(rect_noir,(10,90))
	label = myfont.render("Cliquer sur la porte pour sortir et autre part pour recommencer",1,(255,255,255))
	fen.blit(label,(10,90))
	pygame.display.update()
	ok = 1
	while ok :
		e = pygame.event.get()
		for a in e :
			if a.type == pygame.MOUSEBUTTONUP :
				x,y = pygame.mouse.get_pos()
				if 310<=x<=370 and 20<=y<=80 :
					done = True
					ok = 0
				else :
					ok = 0
print ("***** Fin du programme *****")
pygame.quit
